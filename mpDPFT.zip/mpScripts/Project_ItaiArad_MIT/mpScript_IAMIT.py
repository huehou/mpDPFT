#!/usr/bin/env python3
import sys

def main():
    try:
        # Convert command-line arguments (excluding the script name) to floats.
        numbers = [float(x) for x in sys.argv[1:]]
    except ValueError:
        sys.stderr.write("Invalid input")
        sys.exit(1)
    # Write the result (the sum) to stdout.
    result = sum(numbers)
    sys.stdout.write(str(result))

if __name__ == "__main__":
    main()
