#!/usr/bin/python3

########################################################################
#
#
#                   pepsdm.py
#                   ==========
#
#
# History:
# ---------
#
# 31-Mar-2025  Itai  Initial version.
#
# 15-Apr-2025  Itai  changed name from noisy-DM-PEPS-sim.py, and 
#                    turn it into a module
#
#
#
#
########################################################################


import sys
import time

import numpy as np
import scipy as sp

from scipy.optimize import minimize

import pickle
import time

from numpy import tensordot, zeros, conj, ones, array, exp, sqrt, pi, \
	dot, vdot, eye, log, trace, diag, sign

from numpy.linalg import norm, det, inv
from scipy.linalg import expm

from qbp import calc_e_dict, qbp, get_Bethe_free_energy
from BPSU import BP_gauging, apply_2local_gate, merge_SU_weights

from TenQI import *

#
# ------------------------  initialize  ----------------------------
#

def pepsdm_initialize():

	"""

	Set some global variables.

	Create a global list of 1-local Paulis and a list of 2-local Paulis.

	These lists are used in the comp_to_PTM function for finding the PTM
	representation of a Kruas channel in the computational basis

	"""

	global Paulis2, Paulis1, Paulis1arr, Paulis2arr, \
		CNOT01, CNOT10, H, sZ_gate, sX_gate, T_gate

	#
	# 1D list and 2D list of the Pauli matrices. This is used for
	# bookkeeping k=1 and k=2 channels in the PTM.
	#

	Paulis1 = [ID1, sigma_X, sigma_Y, sigma_Z]

	Paulis2 = [[None]*4 for i in range(4)]
	

	for i in range(4):
		for j in range(4):
			T = tensordot(Paulis1[i], Paulis1[j], 0)
			Paulis2[i][j] = op_to_mat(T)

	#
	# We also create an array-version of Paulis lists
	#
	Paulis1arr = zeros([4,2,2], dtype=np.complex128)
	Paulis2arr = zeros([4,4,2,2,2,2], dtype=np.complex128)
	
	Paulis1arr[0,:,:] = ID1.copy()
	Paulis1arr[1,:,:] = sigma_X.copy()
	Paulis1arr[2,:,:] = sigma_Y.copy()
	Paulis1arr[3,:,:] = sigma_Z.copy()
	
	for al in range(4):
		for beta in range(4):
			Paulis2arr[al,beta,:,:,:,:] = tensordot(Paulis1[al],Paulis1[beta],0)
	

	#
	# Some useful unitary gates
	#

	CNOT01 = tensordot(ketbra00, ID1, 0) +  tensordot(ketbra11, sigma_X, 0)
	CNOT10 = CNOT01.transpose([2,3,0,1])

	H = array([[1,1],[1,-1]])/sqrt(2)

	sZ_gate = diag([1,1j])
	sX_gate = 0.5*array([ [1+1j, 1-1j], [1-1j, 1+1j]])
	
	T_gate = diag([1, exp(1j*pi/4)])




#
# -----------------------  comp_to_PTM  ---------------------
#

def comp_to_PTM(F):

	r"""

	Given a Kraus operator F, produces the tensor that represnets
	the super-operator F\cdot F^\dagger in the PTM representation.


	Input Parameters:
	-------------------
	F --- The Kraus operator.
	      F can be either 1 local or 2 local. In the 2-local case, it is
	      given as a tensor in the form [i0,j0; i1,j1] where

	      F = \sum_{i0,j0; i1,j1} U[i0,j0; i1,j1] \cdot |i0><j0| \otimes |i1><j1|


	Output:
	-------

	The super-operator in PTM representation:

	(*)  for 1-local: T_{bet,al}
	(*)  for 2-local: T_{bet0,al0; bet1,al1}

	Explicitly, for the 2-local case, for

	rho = sum_{al0,al1} rho_{al0,al1} sigma_al0\otimes \sigma_al1

	We have:

	E(rho) = sum_{bet0,bet1} rho'_{bet0,bet1} sigma_bet0\otimes \sigma_bet1

	where:

	rho'_{bet0,bet1} := \sum_{al0,al1} T_{bet0,al0; bet1,al1} rho_{al0,al1}



	"""


	k = len(F.shape)//2

	if k==1:
		#
		# It's a 1-qubit gate. Resulting tensor is T_{alpha,beta}
		#
		
		P_alpha_F = tensordot(Paulis1arr, F, axes=([2],[0]))
		P_beta_Fdag =  tensordot(Paulis1arr, conj(F.T), axes=([2],[0]))
		
		# our tensors are of the form [alpha, i, j]
		
		T = (tensordot(P_alpha_F, P_beta_Fdag, axes=([1,2],[2,1]))).real

	if k==2:
		#
		# It's a 2-qubits operator.
		#
		# Tensor should be of the form [alpha0,beta0; alpha1,beta1]
		#

			
		#
		# Recall, Paulis2arr is of the form:
		# [al0,al1; i0,j0; i1,j1]
		#
		# U is of the form [i0,j0; i1,j1]
		#
		
		P_alpha_F = tensordot(Paulis2arr, F, axes=([3,5],[0,2]))
		P_beta_Fdag = tensordot(Paulis2arr, conj(F), axes=([3,5],[1,3]))
		
		#                                0   1      2  3  4 5
		# Now P_alpha_F is of the form [al0,al10; i0,i1,j0,j1]
		# P_beta_Fdag form:            [beta0,beta1; 
		
		T = (tensordot(P_alpha_F, P_beta_Fdag, axes=([2,3,4,5],[4,5,2,3]))).real
		#
		# T form: [al0,al1,beta0,beta1]
		#
		T = T.transpose([0,2,1,3])


	T = T/2**k
	return T

#
# -----------------------  channel_to_PTM  ---------------------
#

def channel_to_PTM(F_list):
	
	r"""
	
	Given a Kraus channel \sum_k F_k \rho F_k^\dagger, this function
	returns the representation of the channel in the PTM representation.
	
	Input Parameters:
	-----------------
	F_list --- A list of (either 1-local or 2-local) Kraus operators in 
	           the computational basis
	
	Output:
	-------
	The PTM of the channel
	
	"""
	
	M = None
	
	for F in F_list:
		#
		# Go over all the Kraus operators of the channel, and turn each 
		# one of them to a PTM matrix. Then we add all these matrices 
		# together to get the PTM matrix of the total channel
		#
		
		FM = comp_to_PTM(F)
		
		if M is None:
			M = FM
		else:
			M = M + FM
			
	return M

	

#
# -------------------------   get_gate   -------------------------------
#

def get_gate(gname, params=None):
	
	"""
	
	Given a gate name (a string) and an optional parameter (like 
	the rotation angle in a single-qubit rotation), return
	the corresponding local channel in the PTM form.
	
	To do that, we first create a Kraus representation of the channel, 
	as a list of Kraus operators, and then call the channel_to_PTM
	function to turn it into a matrix in the PTM representation.
	
	Input Parameters:
	------------------
	gname  --- A string containing the name of the gate 
	
	params --- A dictionary containing optional parameters for the gate
	
	
	Output:
	-------
	M --- A tensor with k input legs (dim=4) and k output legs that
	      encodes the channel in the PTM representation.
	
	"""
	
	
	match gname:
		
		case 'Id':
			F_list = [ID1]
			
		case 'x':
			F_list = [sigma_X]
				
		case 'y':
			F_list = [sigma_Y]
			
		case 'z':
			F_list = [sigma_Z]
			
		case 'H':
			F_list = [H]
			
		case 'sx':
			F_list = [sX_gate]
			
		case 'sz':
			F_list = [sZ_gate]
			
		case 'T':
			F_list = [T_gate]
			
		case 'CNOT01':
			F_list = [CNOT01]
			
		case 'CNOT10':
			F_list = [CNOT10]
			
		case 'rx':
			theta = params['theta']
			F_list = [expm(-0.5j*theta*sigma_X)]
		
		case 'ry':
			theta = params['theta']
			F_list = [expm(-0.5j*theta*sigma_Y)]

		case 'rz':
			theta = params['theta']
			F_list = [expm(-0.5j*theta*sigma_Z)]
			
		#
		# Noise gates
		#
		
		case 'N_depo':
			lam = params['lam']
			F_list = [sqrt(1-0.75*lam)*ID1, sqrt(0.25*lam)*sigma_X, \
				sqrt(0.25*lam)*sigma_Y, sqrt(0.25*lam)*sigma_Z]
			
		case _:
			print(f"Error!  gate {gname} undefined")
			exit(1) 
			
	#
	# move from the computational basis to PTM
	#
	
	M = channel_to_PTM(F_list)
			
	return M



#
# ---------------------------   avPstr   ------------------------------
#

def avPstr(TN_params, BP_params, Pstr):
	"""
	
	Uses BP to calculates the (un-normalized) expectation value of a 
	Pauli string 
	
	<P> := Tr(\rho P)
	
	
	Input Parameters:
	------------------
	TN_params --- A dictionary holding the TN parameters
	
	BP_params --- A dictionary holding the BP params
	
	Pstr --- A list or integer array of length n that holds the Pauli
	         string. Each entry A[i] is a number is {0,1,2,3}, of the 
	         corresponding Pauli.
	         
	Output:
	-------
	The real number Tr(\rho P)
	
	"""

	#
	# Extract the TN params and the BP params
	#
	T_list = TN_params['T_list']
	e_list = TN_params['e_list']
	e_dict = TN_params['e_dict']


	BP_max_iter = BP_params['BP_max_iter']
	BP_delta    = BP_params['BP_delta']
	BP_damping  = BP_params['BP_damping']
	
	#
	# Contract the physical legs of the PEPS with the local Paulies
	#

	pT_list = []
	for i, T in enumerate(T_list):
		al = Pstr[i]
		pT = T[al,:]
		
		if norm(pT)<1e-13*norm(T):
			return 0.0
		
		pT_list.append(pT)

	
	#
	# Run BP 
	#
		
	m_list, err, iter_no = qbp(pT_list, e_list, e_dict, initial_m='U',\
		max_iter=BP_max_iter, delta=BP_delta, damping=BP_damping)
	
	for e in e_dict.keys():
		i,i_leg, j, j_leg = e_dict[e]
		
	F_Bethe = get_Bethe_free_energy(m_list, pT_list, e_list, e_dict)
	
	if F_Bethe.real>300:
		trTN = 0.0
	else:
		trTN = exp(-F_Bethe)
		
		#
		# By definition, the expectation value of Pauli string is real
		#
		trTN = trTN.real
		
	return trTN
		
	
	
	


#
# ---------------------------   avH   ------------------------------
#

def avH(TN_params, BP_params, H_list, nr=False):
	
	"""
	
	Calculate the energy of an MPS state with respect to a Hamiltonian.
	
	Input Parameters:
	------------------
	mp     --- The MPS
	
	H_list --- The Hamiltonian, given as a list of taples (c, Pstr), 
	           where Pstr is an integer array specifying a Pauli string
	           and c is the coefficient of this string in the expansion
	           of H
	           
  nr     --- Whether or not to normalize the result, 
             i.e. Tr(\rho H)/Tr(\rho)
	
	Output:
	-------
	The expectation value Tr(rho H)  (or Tr(rho H)/Tr(rho))
	
	"""

	M = TN_params['M']
	
	av = 0.0

	if nr:
		#
		# Normalize
		#
		
		n = len(TN_params['T_list'])
		IDstr = zeros(n, dtype=np.int32)

		Tr_rho = avPstr(TN_params, BP_params, IDstr)
	else:
		Tr_rho = 1

	
	for (c, Pstr) in H_list:
		
		local_av = avPstr(TN_params, BP_params, Pstr)/Tr_rho
		
		#
		# If M != None then we simulate a shot-noise due to M measurements
		#
		
		if M is not None:
			local_av += np.random.normal()*sqrt( (1-local_av**2)/M)
		
		av += c*local_av
		
	return av
	
		
#
# ------------------------   apply_gate   ------------------------------
#		

def apply_gate(TN_params, BP_params, gate, t):
	"""
	
	Applies a 1- or 2-local gate to the TN. The gate is actually a 
	channel given in the Kraus representation in the computational basis.
	
	If the gate is 1-local, then we directly apply it to the phyical leg
	of the TN. 
	
	If the gate is 2-local, we first run BP, then move the Vidal gauge,
	apply the gate and truncate to the Dmax parameter of the TN.
	
	The gate is given as a taple: (gname, i, j, params), where:
	
     gname ---  The string that identifies the gate (defined in the
	              get_gate() function)       
	   i,j   ---  The  vertices on which it is defined. Note (i,j) must
	              be an edge in the TN graph
	   params --- optional parameters dictionary for the gate (used in 
	              the get_gate() function)
	              
	Input Parameters:
	-----------------
	TN_params --- A dictionary with the TN parameters
	
	BP_params --- A dictionary with the BP parameters
	
	gate      --- The taple of the gate (see above)
	
	t         --- An optional integer specifying the time step. This is
	              only used in the output message
	              
	              
	Output:
	-------
	T_list    --- The updated tensors
	m_list    --- The output BP messages (can be re-used later)
	trunc_err --- Truncation error (if gate is 2-local)
	
	"""

	log = False

	#
	# Extract the gate parameters
	#
	
	gname, i, j, params = gate
	
	#
	# Get the gate in the PTM form
	#
	M = get_gate(gname, params)
	
	if log:
		print("\n")
		if j is None:
			print(f"Step {t}: applying the 1-local gate {gname} on qubit {i}")
		else:
			print(f"Step {t}: applying the 2-local gate {gname} on qubits {i,j}")

	#
	# Extract the TN params and the BP params
	#
	T_list = TN_params['T_list']
	e_list = TN_params['e_list']
	e_dict = TN_params['e_dict']
	D_max  = TN_params['D_max']
	
	#
	# See if the gate is 1-local or 2-local. In the 1-local case, we 
	# simply apply it on the physical leg. In the 2-local case, we need
	# to run BP, move to the Vidal gauge, apply the gate and then compress.
	#
	
	if j is None:
		#
		# -------------- 1-local gate ------------------
		#
		
		T = T_list[i]
		T_list[i] = tensordot(M, T, axes=([1],[0]))
		
		T_list[i] = T_list[i]/norm(T_list[i])
		
		
		m_list = BP_params['m_list']
		
		trunc_err = 0
		
	else:
		#
		# -------------- 2-local gate ------------------
		#

		#
		# First, we find the edge that connects i,j
		#
		
		es_i, es_j = e_list[i], e_list[j]
		common_es = list(set(es_i).intersection(es_j))
		
		if len(common_es) != 1:
			print("\n")
			print(f"Error!!! vertices {i},{j} do not have a common unique edge")
			exit(1)
			
		e = common_es[0]

		#
		# Next, run BP and pass to the Vidal Gauge
		#

		m_list      = BP_params['m_list']
		BP_max_iter = BP_params['BP_max_iter']
		BP_delta    = BP_params['BP_delta']
		BP_damping  = BP_params['BP_damping']
		
		#
		# Run BP 
		#
		
		if log:
			print("\n")
			print("Running BP...")
		
		m_list, err, iter_no = qbp(T_list, e_list, e_dict, initial_m='U', \
			max_iter=BP_max_iter, delta=BP_delta, damping=BP_damping)
		
		if log:
			print("\n")
			print(f"BP finished after {iter_no} iterations with err={err:.6g}")
			
		gT_list, w_dict = BP_gauging(T_list, e_dict, m_list)
		
		#
		# The apply_2local_gate function assumes that e=(i,j) and that
		# i<j. So if i>j, we need to transpose the legs of M
		#
		
		if i>j:
			M = M.transpose([2,3,0,1])
		
		gT_list, w_dict, trunc_err = apply_2local_gate(gT_list, e_list,  \
			e_dict, w_dict, M, e, Dmax=D_max)
			
		gT_list[i] = gT_list[i]/norm(gT_list[i])
		gT_list[j] = gT_list[j]/norm(gT_list[j])
			
		T_list = merge_SU_weights(gT_list, e_dict, w_dict)
			
			
	
	
	return T_list, m_list, trunc_err

#
#----------------------   simulate_to_end    ---------------------------
#

def simulate_to_end(TN_params, BP_params, gates_list, H_list, t=0, \
	total_err=0):
		
	"""
	
	Given a TN that represents a mixed state and a list of gates (channels)
	the functution acts with the gates on the TN and propagate it to the
	final state. Then it measures the expectation value of the Hamiltonian
	
	Input Parameters:
	------------------
	
	TN_params --- A dictionary with the TN parameters that encode the
	              initial state
	
	BP_params --- A dictionary with the BP parameters
	
	gates_list --- The list of gates to act on the initial state
	
	H_list     --- A list of Pauli strings + weights that encode the
	               Hamiltonian that we wish to estimate in the end
	               
	t          --- The sequential number of the first gate in the list.
	               This number is just used for the optional print-out 
	               message
	               
	total_err  --- The truncation error of the simulation *before*
	               the gates were applied. The tuncation errors of the
	               gates are then added to this total error, which is 
	               then sent as an output
	               
	Output:
	-------
	E         --- The expectation value Tr(\rho H) at the end
	
	total_err --- The total truncation error
	
	
	"""
		
	
	for gate in gates_list:
		
		T_list, m_list, trunc_err = apply_gate(TN_params, BP_params, gate, t)
		
		TN_params['T_list'] = T_list
		BP_params['m_list'] = m_list

		total_err += trunc_err
					
		t += 1

	E = avH(TN_params, BP_params, H_list, nr=True)
	
	return E, total_err
	
	
	

# ------------------------   estimate_circ  -------------------------
#

def estimate_circ(TN_params, BP_params, circ, H_list, angles_loc=[], \
	just_grad=False):
	
	r"""

	Given a circuit, a Hamiltonian and a set of locations of 
	differentiable rotations in the circuit, return the energy of the 
	final state \rho with respect to the Hamiltonian, together with 
	gradient of the energy with respect to the rotations.
		
	Input Parameters:
	------------------
	TN_params --- A dictionary with the TN parameters
	
	BP_params --- A dictionary with the BP parameters
	
	circ       --- A dictionary holding the circuit info. This includes:
	
	               (*) circ['n']     --- Number of qubits
	               
	               (*) circ['glist'] --- A list of taples 
	                                     (gate_name, i, params)
	                                     describing the circuit
	                                
	H_list     --- The Hamiltonian as a list of Pauli strings and their
	               weights (c, Pstr)
	           
	
	angles_loc --- A list of positions of the rotations where we want
	               to calculate the gradient. This is done using the 
	               shift-rule.
	         
	
	Output:
	-------
	E         --- The final energy
	grad      --- An array holding the gradient corresponding to angle_loc 
	total_err --- Total truncation error (for the energy calc)
	
	"""
	
	log = False
	
	
	glist = circ['glist']
	
	#
	# Prepare the initial state |0>^n
	#
	e_list = TN_params['e_list']
	T_list = all_zeros(e_list)
	
	TN_params['T_list'] = T_list
	
	T_num = len(glist)
	
	total_err = 0.0
	
	#
	# See if we need to calculate the gradient array or not
	#
	l = len(angles_loc)
	if l>0:
		grad = zeros(l)
	else:
		grad = None
	
	
	m = 0           # Index holding the current gradient location
	total_err = 0.0 # Total truncation error
	
	for t in range(T_num):
		
		gate = glist[t]
		
		(gname, i, j, params) = gate
		if j is None:
			locs=f'{i}'
		else:
			locs=f'{i}-{j}'
	
		if log:
			print("===================================================")
			print(f"At step t={t}/{T_num-1} g[{t}]={gname}({locs})")
			print("===================================================\n")
	
		#
		# See if we reached a rotation in the gradient
		#
		if t in angles_loc:
			
			#
			# If we need to calculate a gradient, then we use the shift-rule
			# and calculate the circuit with theta +/- pi/2.
			#
			# In such case we need to run the circuit twice from where 
			# we are all way to the end. One branch with theta+pi/2 and 
			# the other branch with theta-pi/2
			#
			
			glist1 = glist[t:]  # The circuit starting from here
			params1 = {}
			
			if log:
				print(" **** gate is in grad!! ****\n")
		
			if log:
				print(" > Calculate (+) branch: ")
				print("   ---------------------\n")
			
			#
			# Change theta -> theta+pi/2 and use a fresh copy
			# of the TN
			#
			params1['theta'] = params['theta'] + pi/2
			glist1[0] = (gname, i, j, params1)
			
			T_list1 = T_list.copy()
			TN_params1 = TN_params.copy()
			TN_params1['T_list'] = T_list1
			
			av_plus, err = simulate_to_end(TN_params1, BP_params, \
				glist1, H_list, t, total_err)
				
			if log:
				print(" > Calculate (-) branch: ")
				print("   ---------------------\n")
			
			#
			# Change theta -> theta-pi/2 and use a fresh copy
			# of the TN
			#
			params1['theta'] = params['theta'] - pi/2
			glist1[0] = (gname, i, j, params1)
			
			T_list1 = T_list.copy()
			TN_params1 = TN_params.copy()
			TN_params1['T_list'] = T_list1

			av_minus, err = simulate_to_end(TN_params1, BP_params, \
				glist1, H_list, t, total_err)
			
			#
			# Calculate the gradient using the parameter-shift rule
			#
			grad[m] = 0.5*(av_plus - av_minus)
			m += 1
		
		if just_grad and m==l:
			break
		
		#
		# Apply the gate of step t
		#

		T_list, m_list, trunc_err = apply_gate(TN_params, BP_params, gate, t)
		
		TN_params['T_list'] = T_list
		BP_params['m_list'] = m_list

		total_err += trunc_err
	
	if just_grad:
		E = None
	else:
		#
		# Calculate the energy of the final circuit
		#
		M = TN_params['M']
		TN_params['M']=None
		
		E = avH(TN_params, BP_params, H_list, nr=True)
		
		TN_params['M']=M
		
		
	return E, grad, total_err

	
	
	
	
#
# --------------------------   all_zeros   -----------------------------
#
def all_zeros(e_list):
	r"""
	
	Create an initial TN in the Pauli representation that encodes the 
	state |0>^n
	
	"""
	
	n = len(e_list)
	
	T0 = array([0.5,0,0,0.5])  # Representation of |0><0| in Pauli basis
	
	T_list = []
	
	for es in e_list:
		l = len(es)
		sh = [4] + [1]*l  # the shape of the TN is [4,1,1,...]
		
		T = T0.reshape(sh)
		
		T_list.append(T)
		
	return T_list
			
