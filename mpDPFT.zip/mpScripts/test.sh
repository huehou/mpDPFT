#!/bin/bash

echo "I am test.sh from .../mpScripts/..."
