#ifndef MPSCRIPT_TESTKD_H
#define MPSCRIPT_TESTKD_H

#include <iostream>


void sayHello() {
	std::cout << "Hello from mpScript_testKD.h!" << std::endl;
}
void runMPIExample(int argc, char** argv);

#endif // MPSCRIPT_TESTKD_H
