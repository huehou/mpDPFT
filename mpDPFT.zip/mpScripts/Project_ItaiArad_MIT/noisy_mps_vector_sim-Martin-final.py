#!/usr/bin/python3

########################################################################
#
#
#                    noisy_mps_vector_sim.py
#                   ============================
# A library containing functions for simulating noisy quantum circuits
# using MPS machinary, based on bubblecon
#
#
# History:
# ---------
#
# 9-Feb-2025  Itai  Initial version.
#
#
#
#
########################################################################


import numpy as np
import scipy as sp

import sys

from numpy import tensordot, zeros, conj, ones, array, exp, sqrt, pi, \
	dot, vdot, eye, log, trace, diag, sign

from numpy.linalg import norm, det, inv
from scipy.linalg import expm

from scipy.optimize import minimize

import bmpslib

from TenQI import *


COMPRESSION = 'SVD'  # Either 'SVD' or 'iter'


#
# ---------------------     set_global_vars     ------------------------
#

def set_global_vars():
	
	"""
	
	Set global variables that hold various 1-local and 2-local gates
	
	"""
	
	global CNOT01, CNOT10, sZ_gate, sX_gate, T_gate
	
	CNOT01 = tensordot(ketbra00, ID1, 0) + tensordot(ketbra11, sigma_X, 0)
	
	CNOT10 = CNOT01.transpose([2,3,0,1])

	sZ_gate = diag([1,1j])
	sX_gate = 0.5*array([ [1+1j, 1-1j], [1-1j, 1+1j]])
	
	T_gate = diag([1, exp(1j*pi/4)])
	



#
# ---------------------     all_zeros_mps     -------------------------
#

def all_zeros_mps(n):
	"""
	
	Creates an mps encoding the state |0>^n
	
	"""
	
	mp = bmpslib.mps(n)
	
	A = zeros([1,2,1])
	A[0,0,0] = 1.0
	
	for i in range(n):
		mp.set_site(A, i)
		
	return mp
	
#
# -------------------------   get_gate   -------------------------------
#

def get_gate(gname, params=None):
	
	"""
	
	Given a gate name (a string) and an optional parameter (like 
	the rotation angle in a single-qubit rotation), return
	the corresponding unitary gate
	
	
	"""
	
	
	match gname:
		
		case 'Id':
			g = ID1
			
		case 'x':
			g = sigma_X
				
		case 'y':
			g = sigma_Y
			
		case 'z':
			g = sigma_Z
			
		case 'H':
			g = H
			
		case 'sx':
			g = sX_gate
			
		case 'sz':
			g = sZ_gate
			
		case 'T':
			g = T_gate
			
		case 'CNOT01':
			g = CNOT01
			
		case 'CNOT01n':
			g = tensordot(ID1, ID1, 0)
			
		case 'CNOT10':
			g = CNOT10
			
		case 'rx':
			theta = params['theta']
			g = expm(-0.5j*theta*sigma_X)
		
		case 'ry':
			theta = params['theta']
			g = expm(-0.5j*theta*sigma_Y)

		case 'rz':
			theta = params['theta']
			g = expm(-0.5j*theta*sigma_Z)
			
	return g
	

#
# ---------------------   apply_1local_gate   --------------------------
#

def apply_1local_gate(mp, U, i):
	"""
	
	Apply a 1-local gate on the MPS
	
	Input Parameters:
	-----------------
	
	mp --- The MPS 
	
	U  --- a 2x2 matrix (not necessarily unitary)
	
	i  --- The qubit index
	
	
	Output:
	-------
	The updated MPS
	
	Note: the update is done on the MPS itself.
	
	"""
	
	# A[i] legs are [L, d, R]
	
	A = tensordot(U, mp.A[i], axes=([1],[1])) 
	
	# now A legs are [d,L,R] --- transpose them to [L,d,R]
	A = A.transpose([1,0,2])
	
	mp.set_site(A, i)
	
	return mp
	
	
#
# ---------------------   apply_2local_gate   --------------------------
#

def apply_2local_gate(mp, U, i):
	"""
	
	Apply a 2-local gate on the MPS at location i,i+1
	
	Input Parameters:
	-----------------
	
	mp --- The MPS 
	
	U  --- a 2-local gate,  (given in the form U_{i1j1; i2j2})
	
	i  --- The qubit index. The gate is applied on the (i,i+1) qubits
	
	NOTE: the gate U does not necessarily have to be unitary
	
	Output:
	-------
	The updated MPS
	
	Note: the update is done on the MPS itself.
	
	"""
	
	
	#
	# We first use the QR decomp' to break U into U1*U2, where 
	# U1 acts on i and U2 on i+1
	#
	sh = U.shape
	Umat = U.reshape([sh[0]*sh[1], sh[2]*sh[3]])
	U1, U2 = np.linalg.qr(Umat)
	
	sh1 = U1.shape
	sh2 = U2.shape
	
	U1 = U1.reshape([sh[0],sh[1],sh1[1]])
	U2 = U2.reshape([sh2[0], sh[2],sh[3]])
	
	#
	# ==== Apply U1 on leg i
	#
	
	# A[i] legs are [L, d, R]
	# U1 legs are [d_bra, d_ket, D]
	
	A1 = tensordot(U1, mp.A[i], axes=([1],[1])) 
	
	#
	# now A1 legs are [d_bra, D, L, R]
	# So we move it to [L, d_bra, D, R] and fuse (D,R) together
	#
	A1 = A1.transpose([2,0,1,3])
	sh = A1.shape
	A1 = A1.reshape([sh[0], sh[1], sh[2]*sh[3]])
	mp.set_site(A1, i)


	#
	# ==== Apply U2 on leg i+1
	#
	
	# A[i+1] legs are [L, d, R]
	# U2 legs are [D, d_bra, d_ket]
	
	A2 = tensordot(U2, mp.A[i+1], axes=([2],[1])) 
	
	#
	# now A2 legs are [D, d_bra, L, R]
	# So we move it to [D, L, d_bra, R] and fuse (D,L) together
	#
	A2 = A2.transpose([0,2,1,3])
	sh = A2.shape
	A2 = A2.reshape([sh[0]*sh[1], sh[2],sh[3]])
	mp.set_site(A2, i+1)
	
	return mp
	
#
#  ----------------------   apply_gate   ----------------------------
#


def apply_gate(mp, gname, i, params, maxD, gate_t=None):
	
	"""
	
	Applies a gate on an MPS and compress the MPS (if needed)
	
	Input Parameters:
	-----------------
	mp     --- The MPS
	
	gname  --- A string holding the gate name (used via get_name)
	
	i      --- The location of the qubit on which we apply. If we apply a 
	           2-local gate, then its in locations (i,i+1)
	      
	params --- optional dictionary of parameters for the gate
	
	maxD   --- Maximal bond dimension after compression. Only applies
	           if the gate is 2-local
	         
	gate_t --- Optional parameter holding the time-step. Only used
	           in the output message
	           
	Output:
	-------
	
	mp        --- The updated MPS (done on the original MPS)
	
	trunc_err --- The relative truncation error (L_2 norm)
	
	
	"""
	
	log = False
	
	g = get_gate(gname, params)
		
	k = len(g.shape)//2
	if log:
		if gate_t is None:
			gate_t = '..'
		print(f"\nGate[{gate_t}] = {gname} ({k}-local) on i={i}  params={params}")
	
	if k==1:
		#
		# If its a 1-local gate, just apply it --- no truncation is needed.
		#
		mp = apply_1local_gate(mp, g, i)
		trunc_err = 0.0
		
	if k==2:
		#
		# If its a 2-local gate, then compress after aplying it.
		#
		
		mp = apply_2local_gate(mp, g, i)
		
		trunc_err = mp.reduceD(maxD=maxD, mode='MC', nr_bulk=True)
		
		if log:
			print(f" => Compressing... trucation-err={trunc_err:.6g} ")
			
	return mp, trunc_err

	

#
# ---------------------------   avPstr   ------------------------------
#

def avPstr(mp, Pstr):
	"""
	
	Given an MPS mp of a state |psi>, and Pauli string Pstr, which 
	represents a Pauli operator P, returns <psi|P|psi>
	
	Note: we do *not* normalize the expression by <psi|psi>
	
	Input Parameters:
	------------------
	mp --- The MPS of |psi>
	
	Pstr --- A list or integer array of length n that holds the Pauli
	         string. Each entry A[i] is a number is {0,1,2,3}, of the 
	         corresponding Pauli.
	         
	Output:
	-------
	The real number <psi|P|psi>
	
	"""
	
	n = mp.N

	#
	# Create MPS mp1, which is the action of Pstr on mp
	#
	mp1 = mp.copy()
	for i in range(n):
		al = Pstr[i]
		
		if al==0:
			continue
			
		P = U_Pauli_to_op[:,:,al]
		apply_1local_gate(mp1, P, i)
		
	av = bmpslib.mps_inner_product(mp1, mp, conjB=True)
	av = av.real
	
		
	return av
	





#
# ---------------------------   avH   ------------------------------
#

def avH(mp, H_list, nr=False, M=None):
	
	"""
	
	Calculate the energy of an MPS state with respect to a Hamiltonian.
	
	Input Parameters:
	------------------
	mp     --- The MPS
	
	H_list --- The Hamiltonian, given as a list of taples (c, Pstr), 
	           where Pstr is an integer array specifying a Pauli string
	           and c is the coefficient of this string in the expansion
	           of H
	           
  nr     --- Whether or not to normalize the result, 
             i.e. <psi|H|psi>/<psi|psi>
	
	Output:
	-------
	The expectation value <psi|H|psi>  (or <psi|H|psi>/<psi|psi>)
	
	"""

	
	av = 0.0
	
	if nr:
		#
		# Normalize
		#

		mp_norm2 = bmpslib.mps_inner_product(mp, mp, conjB=True)
		mp_norm2 = mp_norm2.real
		
	else:
		mp_norm2 = 1
		
	
	for (c, Pstr) in H_list:
		
		local_av = c*avPstr(mp, Pstr)/mp_norm2
		
		if M is not None:
			local_av = local_av + np.random.normal()*sqrt( (1-local_av**2)/M)
	
		av += local_av
		
		
		
		
	return av
		
#
# -------------------   simulate_to_end   -----------------------------
#

def simulate_to_end(mp, gates_list, H_list, maxD, t=0, total_err=0.0, M=None):
	"""
	
	Given an initial state, a circuit and a Hamiltonian, calculate the 
	final state and output the expected energy of the Hamiltonian.
	
	Input Parameters:
	-----------------
	
	mp         --- An MPS holding the initial state
	
	gates_list --- A list of gates that describe the circuit. Each element
	               of the list is a taple (gname, i, params)
	               
	H_list     --- A list of Pauli strings and coefficients describing the 
	               Hamiltonian 
	           
	maxD       --- The maximal bond dimension of the MPS (used when 
	               compressing the MPS)
	
	t          --- The time step we start from
	
	total_err  --- The total truncation error we start from
	
	
	Output:
	-------
	The expression <psi|H|psi> and the total truncation error.
	
	
	"""
	
	
	for (gname, i, params) in gates_list:
		
		mp, trunc_err = apply_gate(mp, gname, i, params, maxD, t)

		total_err += trunc_err
				
		t += 1

	bra_H_ket = avH(mp, H_list, True, M)
	
	return bra_H_ket, total_err
			


#
# ------------------------   estimate_circ  -------------------------
#

def estimate_circ(circ, H_list, maxD, angles_loc=[], M=None):
	
	"""
	
	Given a circuit, a Hamiltonian and a set of locations of 
	differentiable rotations in the circuit, return the energy of the 
	state |psi> = U|0>^n with respect to the Hamiltonian, together with 
	gradient of the energy with respect to the rotations.
	
	The calculation is done in the ideal case:
	 (-) There is no noise
	 (-) There is no measurement error. We directly calculate 
	     expectation values like <psi|H|psi>
	
	Input Parameters:
	------------------
	
	circ       --- A dictionary holding the circuit info. This includes:
	
	               (*) circ['n']          --- Number of qubits
	               
	               (*) circ['gates_list'] --- A list of taples 
	                                          (gate_name, i, params)
	                                          describing the circuit
	                                
	H_list     --- The Hamiltonian as a list of Pauli strings and their
	               weights (c, Pstr)
	           
	maxD       --- Maximal bond dimension of the MPS
	
	angles_loc --- A list of positions of the rotations where we want
	               to calculate the gradient. This is done using the 
	               shift-rule.
	         
	
	Output:
	-------
	E         --- The final energy
	grad      --- An array holding the gradient 
	total_err --- Total truncation error (for the energy calc)
	
	"""
	
	log = False
	
	n = circ['n']
	
	gates_list = circ['glist']
	
	mp = all_zeros_mps(n)
	
	T = len(gates_list)
	
	total_err = 0.0
	
	#
	# See if we need to calculate the gradient array or not
	#
	l = len(angles_loc)
	if l>0:
		grad = zeros(l)
	else:
		grad = None
	
	
	m = 0           # Index holding the current gradient location
	total_err = 0.0 # Total truncation error
	
	for t in range(T):
		(gname, i, params) = gates_list[t]
	
		if log:
			print("===================================================")
			print(f"At step t={t}")
			print("===================================================\n")
	
		#
		# See if we reached a rotation that needs to be in the gradient
		#
		if t in angles_loc:
			
			#
			# If we need to calculate a gradient, then we use the shift-rule
			# and calculate the circuit with theta +/- pi/2.
			#
			# In such case we need to run the circuit twice from where 
			# we are all way to the end. One branch with theta+pi/2 and 
			# the other branch with theta-pi/2
			#
			
			gates_list1 = gates_list[t:]  # The circuit starting from here
			params1 = {}
			
			if log:
				print(" **** gate is in grad!! ****\n")
		
			if log:
				print(" > Calculate (+) branch: ")
				print("   ---------------------\n")
			
			params1['theta'] = params['theta'] + pi/2
			gates_list1[0] = (gname, i, params1)
			mp1 = mp.copy()
			av_plus, err = simulate_to_end(mp1, gates_list1, H_list, maxD, t,\
				total_err, M)

			if log:
				print(" > Calculate (-) branch: ")
				print("   ---------------------\n")
			
			params1['theta'] = params['theta'] - pi/2
			gates_list1[0] = (gname, i, params1)
			mp1 = mp.copy()
			av_minus, err = simulate_to_end(mp1, gates_list1, H_list, maxD,\
				t, total_err, M)
			
			#
			# Shift-rule
			#
			grad[m] = 0.5*(av_plus - av_minus)
			m += 1
		
		#
		# Apply the gate
		#
		mp, trunc_err = apply_gate(mp, gname, i, params, maxD, t)

		total_err += trunc_err
				
	
	E = avH(mp, H_list, True, M)
		
	return E, grad, total_err




#
# -----------------------   HVA_TIM   ----------------------------------
#
def HVA_TIM(n,g, L):
	
	r"""
	"""
	
	circ = {}
	
	glist = []
	
	angles_loc = []
	
	t=0
	theta = 0.0
	
	
	#
	# Initial H layer (g.s. of H_x)
	#
	
	
	for i in range(n):
		glist.append( ('H', i, None) )
		t += 1
	
	#
	# Add L layers of Rzz + Rx
	#
	for l in range(L):
					
		#
		# Odd Rzz layer
		#
		theta = 0.0
			
		for i in range(0,n-1,2):
			glist.append( ('CNOT01', i, None) )
			t += 1

		for i in range(0,n-1,2):
			glist.append( ('rz', i+1, {'theta':theta}) )
			angles_loc.append(t)
			t += 1
		
		for i in range(0,n-1,2):
			glist.append( ('CNOT01', i, None) )
			t += 1
	
		#
		# Even Rzz layer
		#
			
		for i in range(1,n-1,2):
			glist.append( ('CNOT01', i, None) )
			t += 1

		for i in range(2,n,2):
			glist.append( ('rz', i, {'theta':theta}) )
			angles_loc.append(t)
			t += 1
		
		for i in range(1,n-1,2):
			glist.append( ('CNOT01', i, None) )
			t += 1

		#
		# Rx layer
		#
		
		theta = 0.0
		
		for i in range(n):
			glist.append( ('rx', i, {'theta':theta}) )
			angles_loc.append(t)
			t += 1




	
	circ['glist'] = glist
	circ['n']=n
	
	
	#
	# Now define the TIM Hamiltonian with transverse field g
	#
	H_list = []
	
	for i in range(n-1):
		Pstr = zeros(2*n, dtype=np.int32)
		Pstr[i]   = 3
		Pstr[i+1] = 3
		H_list.append( (-1, Pstr) )
	
	for i in range(n):
		Pstr = zeros(2*n, dtype=np.int32)
		Pstr[i]=1
		H_list.append( (-g, Pstr) )
	
	return circ, angles_loc, H_list


	
#
# ------------------------  scipy_f  ---------------------------------
#	
	
def scipy_f(x, sp_params):
	
	theta = x
	
	n = sp_params['n']
	L = sp_params['L']
	M = sp_params['M']
	
	maxD       = sp_params['maxD']
	circ       = sp_params['circ']
	H_list     = sp_params['H_list']
	angles_loc = sp_params['angles_loc']
	
	#
	# Assign the angles x to the circuit
	#
	glist = circ['glist']
	for l in range(L):
		
		i0 = l*(2*n-1)

		#
		# Update the Rzz of layer l (n-1) rotations
		#
		for i in range(i0, i0+n-1):
			t = angles_loc[i]
			gname, q, params = glist[t]
			params['theta'] = theta[2*l]
			

		#
		# Update the Rxz of layer l (n rotations)
		#
		for i in range(i0+n-1, i0+2*n-1):
			t = angles_loc[i]
			gname, q, params = glist[t]
			params['theta'] = theta[2*l+1]

	
	#
	# run the circuit. Find the energy *without* the gradient
	#
	
	E, grad, total_err = estimate_circ(circ, H_list, maxD, angles_loc=[], M=M)
		
	return E




#
# ---------------------- just_energy ------------------------------
#

def just_energy():
	

	#
	# ------------------   SET MAIN PARAMETERS  ------------------------
	#

	n = 4
	L = 6
	g = 0.6
	
	# 
	# Shot-noise parameter: 
	#   M = how many shots used to evaluate expectation value. 
	#       Use M=None to elimitate shot-noise.
	#
	
	M = None
	
	D_MAX       = 2**(n//2)+1  # MPS truncation bond
	
	#
	# Random number generator seed
	#
	
	seed = 1
	
	
	#
	# ---------------------  PROGRAM STARTS HERE  -----------------------
	#

	set_global_vars()

	# np.random.seed(seed)

	circ, angles_loc, H_list = HVA_TIM(n,g,L)
	
	sp_params={}
	sp_params['n'] = n
	sp_params['L'] = L
	sp_params['M'] = M
	sp_params['maxD']  = D_MAX
	sp_params['circ']       = circ
	sp_params['H_list']     = H_list
	sp_params['angles_loc'] = angles_loc

	angles = [float(x) for x in sys.argv[1:]]
	theta = array(angles)
	
	E = scipy_f(theta, sp_params)
	
	sys.stdout.write(str(E))
	

just_energy()
