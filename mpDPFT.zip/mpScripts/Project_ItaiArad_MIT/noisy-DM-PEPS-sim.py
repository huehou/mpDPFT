#!/usr/bin/python3

########################################################################
#
#
#                   noisy-DM-PEPS.py
#                   =================
#
#
# History:
# ---------
#
# 31-Mar-2025  Itai  Initial version.
#
#
#
#
########################################################################


from os import environ, uname
N_THREADS = '1'
environ['OMP_NUM_THREADS'] = N_THREADS

import sys
import time

import numpy as np
import scipy as sp

from scipy.optimize import minimize

import pickle
import time

from numpy import tensordot, zeros, conj, ones, array, exp, sqrt, pi, \
	dot, vdot, eye, log, trace, diag, sign

from numpy.linalg import norm, det, inv
from scipy.linalg import expm

from qbp import calc_e_dict, qbp, get_Bethe_free_energy
from BPSU import BP_gauging, apply_2local_gate, merge_SU_weights

from TenQI import *

from pepsdm import *


try:
	from mpi4py import MPI
except ImportError as e:
	pass  # module doesn't exist, deal with it.
	MPI=None


#
# -------------------------   comb_graph   -----------------------------
#

def comb_graph(n):
	
	r"""
	
	Creates a "comb" TN graph with n data qubits and n ancila qubits.
	
	For example, for n=5, we have the following graph:
	
	  5       6       7       8       9
	  |       |       |       |       |
	 leg-0   leg-1   leg-2   leg-3   leg-4
	  |       |       |       |       |
	  0-------1-------2-------3-------4
	    e0-1     e1-2    e2-3    e3-4
	    
	    
	For a data qubit k, the order of the legs are: 
	e{k-1}-k, e{k}-{k+1}, leg-k
	
	Input Parameters:
	-----------------
	n --- number of "legs" in the comb
	
	Output:
	-------
	
	e_list, e_dict --- The data structure of the TN graph
	
	"""
	
	e_list = []
	
	#
	# add the edges of the data qubits 0,1,..., n-1
	#
	for i in range(n):
		es = []
		
		if i>0:
			es.append(f'e{i-1}-{i}')
			
		if i<n-1:
			es.append(f'e{i}-{i+1}')
			
		es.append(f'leg-{i}')
		
		e_list.append(es)
		
	#
	# Add the edges of the ancilas
	#

	for i in range(n):
		es = [f'leg-{i}']
		e_list.append(es)

	e_dict = calc_e_dict(e_list)
		
	return e_list, e_dict
	
#
# -----------------------   HVA_TIM   ----------------------------------
#
def HVA_TIM(n,g, L, lam=None):
	
	r"""
	"""
	
	circ = {}
	
	glist = []
	
	angles_loc = []
	
	t=0
	
	theta = 0.0
	
	#
	# Initial H layer (g.s. of H_x)
	#
	
	
	for i in range(n):
		glist.append( ('H', i, None, None) )
		t += 1
	
	#
	# Add L layers of Rzz + Rx
	#
	for l in range(L):

		#
		# Odd Rzz layer
		#
		
		for i in range(0,n-1,2):
			glist.append( ('CNOT01', i, i+1, None) )
			t += 1
			
		if lam is not None:
			for i in range(n):
				glist.append( ('N_depo', i, None, {'lam':lam}) )
				t += 1

		for i in range(0,n-1,2):
			glist.append( ('rz', i+1, None, {'theta':theta}) )
			angles_loc.append(t)
			t += 1
		
		for i in range(0,n-1,2):
			glist.append( ('CNOT01', i, i+1, None) )
			t += 1

		if lam is not None:
			for i in range(n):
				glist.append( ('N_depo', i, None, {'lam':lam}) )
				t += 1
	
		#
		# Even Rzz layer
		#
			
		for i in range(1,n-1,2):
			glist.append( ('CNOT01', i, i+1, None) )
			t += 1

		if lam is not None:
			for i in range(n):
				glist.append( ('N_depo', i, None, {'lam':lam}) )
				t += 1


		for i in range(2,n,2):
			glist.append( ('rz', i, None, {'theta':theta}) )
			angles_loc.append(t)
			t += 1
		
		for i in range(1,n-1,2):
			glist.append( ('CNOT01', i, i+1, None) )
			t += 1

		if lam is not None:
			for i in range(n):
				glist.append( ('N_depo', i, None, {'lam':lam}) )
				t += 1


		#
		# Rx layer
		#
		
		for i in range(n):
			glist.append( ('rx', i, None, {'theta':theta}) )
			angles_loc.append(t)
			t += 1

	circ['glist'] = glist
	
	#
	# Now define the TIM Hamiltonian with transverse field g
	#
	H_list = []
	
	for i in range(n-1):
		Pstr = zeros(2*n, dtype=np.int32)
		Pstr[i]   = 3
		Pstr[i+1] = 3
		H_list.append( (-1, Pstr) )
	
	for i in range(n):
		Pstr = zeros(2*n, dtype=np.int32)
		Pstr[i]=1
		H_list.append( (-g, Pstr) )
	
	return circ, angles_loc, H_list


#
# ------------------------   ADAM_optimizer   -------------------------
#

def ADAM_optimizier(m, v, g, t):
	
	mode = 'ADAM'
	
	if mode == 'PLAIN':
		return g, 1, 1
	
	if mode == 'SIGN':
		k = g.shape[0]
		nr = norm(g)
		delta = np.random.uniform(size=k)*nr*sign(g)*norm(g)
		return delta, 1, 1
	
	if mode == 'ADAM':
	
		EPSILON = 1e-8  # Prevent division by zero errors

		gamma_1 = 0.9     # Decay for first moment average
		gamma_2 = 0.999   # Decay for second moment average
		
		if m is None:
			m = zeros(g.shape[0])
			v = zeros(g.shape[0])
		
		new_m = gamma_1*m + (1-gamma_1)*g
		new_v = gamma_2*v + (1-gamma_2)*g**2
		
		m_hat = new_m/(1-gamma_1**t)
		v_hat = new_v/(1-gamma_2**t)
		
		delta = m_hat/(sqrt(v_hat)+EPSILON)
			
		return delta, new_m, new_v
	


	
#
# ------------------------  update_angles  -----------------------------
#	

def update_angles(L, n, glist, angles_loc, theta):
	
	for l in range(L):
		
		i0 = l*(2*n-1)

		#
		# Update the Rzz of layer l (n-1) rotations
		#
		for i in range(i0, i0+n-1):
			t = angles_loc[i]
			gname, q0, q1, params = glist[t]
			params['theta'] = theta[2*l]

		#
		# Update the Rx of layer l (n rotations)
		#
		for i in range(i0+n-1, i0+2*n-1):
			t = angles_loc[i]
			gname, q0, q1, params = glist[t]
			params['theta'] = theta[2*l+1]

	return glist


	
#
# ------------------------  scipy_f  ---------------------------------
#	
	
def scipy_f(x, sp_params):
	
	theta = x
	
	n = sp_params['n']
	L = sp_params['L']
	
	
	TN_params  = sp_params['TN_params']
	BP_params  = sp_params['BP_params']
	circ       = sp_params['circ']
	H_list     = sp_params['H_list']
	angles_loc = sp_params['angles_loc']
	
	
	#
	# Assign the angles x to the circuit
	#
	
	glist = update_angles(L, n, circ['glist'], angles_loc, theta)
	
	# for l in range(L):
		
		# i0 = l*(2*n-1)

		# #
		# # Update the Rzz of layer l (n-1) rotations
		# #
		# for i in range(i0, i0+n-1):
			# t = angles_loc[i]
			# gname, q0, q1, params = glist[t]
			# params['theta'] = theta[2*l]
			

		# #
		# # Update the Rx of layer l (n rotations)
		# #
		# for i in range(i0+n-1, i0+2*n-1):
			# t = angles_loc[i]
			# gname, q0, q1, params = glist[t]
			# params['theta'] = theta[2*l+1]

				
	
	#
	# run the circuit. Find the energy *without* the gradient
	#
	
	E, grad, total_err = estimate_circ(TN_params, BP_params, circ, \
		H_list, angles_loc=[])
		
	return E


#
# ------------------------  scipy_jac  ---------------------------------
#	
	
def scipy_jac(x, sp_params):
	
	theta = x
	
	n         = sp_params['n']
	L         = sp_params['L']
	mpi_comm  = sp_params['mpi_comm']
	calcE     = sp_params['calcE']
	
	TN_params  = sp_params['TN_params']
	BP_params  = sp_params['BP_params']
	circ       = sp_params['circ']
	H_list     = sp_params['H_list']
	angles_loc = sp_params['angles_loc']
	
	#
	# Assign the angles x to the circuit
	#
	
	glist = update_angles(L, n, circ['glist'], angles_loc, theta)
	

	#
	# run the circuit. Find the energy *without* the gradient
	#

	if mpi_comm is None:
		
		if calcE:
			E, grad, total_err = estimate_circ(TN_params, BP_params, circ, \
				H_list, angles_loc, just_grad=False)
		else:
			E, grad, total_err = estimate_circ(TN_params, BP_params, circ, \
				H_list, angles_loc, just_grad=True)
			
	else:
		
		grad = zeros(theta.shape[0])
		
		master_id   = mpi_comm.Get_rank()
		slaves_no   = mpi_comm.Get_size()-1 
		
		
		#
		# Tell the slaves to calculate their part of the gradient
		#
		
		for slave_id in range(slaves_no):
			mpi_comm.send( ('grad', theta), dest=slave_id, tag=0)
			
		#
		# Gather their results
		#
		
		slave_grad = [None for i in range(slaves_no)]
		
		for slave_id in range(slaves_no):
			
			if calcE and slave_id==0:
				slave_grad[slave_id],E = mpi_comm.recv(source=slave_id, tag=1)
			else:
				slave_grad[slave_id] = mpi_comm.recv(source=slave_id, tag=1)
			
			
			
		#
		# Combine all slave gradients into one gradient
		#
		
		grad = combine_gradients(slave_grad)
		




	#
	# Use the local gradients to calculate the 2L global gradients.
	#
	# To do that, we go over the layers. Each layer has 2n-1 angles:
	#
	# For even n:
	# ------------
	#  (*)  n     angles of Rx
	#  (*)  n/2   angles of even Rz
	#  (*)  n/2-1 angles of odd  Rz
	#
	# For odd n:
	# ------------
	#  (*)  n       angles of Rx
	#  (*)  (n-1)/2 angles of even Rz
	#  (*)  (n-1)/2 angles of odd  Rz
	
	dtheta = zeros(2*L)

	for l in range(L):
		
		i0 = l*(2*n-1)
		
		#
		# calc the gradient of the Rzz layers
		#
		for i in range(i0, i0+n-1):
			dtheta[2*l] += grad[i]

		#
		# calc the gradient of the R_x layer
		#
		for i in range(i0+n-1, i0+2*n-1):
			dtheta[2*l+1] += grad[i]


	if calcE:
		return dtheta, E
	else:
		return dtheta





#
# ------------------------  get_slaves_partition  -----------------------
#

def get_slaves_partition(n, L, slaves_no, angles_loc):
	
	#
	# How many angles every slave gets at every layer
	#
	k = (2*n-1)//slaves_no
	
	slaves_partition = [ [] for i in range(slaves_no)]
	
	i=0
	for t in angles_loc:
		slaves_partition[i].append(t)
		
		i += 1
		if i==slaves_no:
			i=0
	
	return slaves_partition




#
# ---------------------   combine_gradients   --------------------------
#
def combine_gradients(slave_grad):
	
	slaves_no = len(slave_grad)
	
	k = 0
	for sgrad in slave_grad:
		k += sgrad.shape[0]
		
	grad = zeros(k)
	
	j = 0
	c = 0
	for i in range(k):
		grad[i] = slave_grad[j][c]
		j += 1
		
		if j==slaves_no:
			j=0
			c += 1
		
	return grad


	
#
# -------------------------   mpi_slave   ------------------------------ 
#
def mpi_slave(mpi_comm, sp_params, slave_angles):
	
	log = False
	
	slave_id = mpi_comm.Get_rank()
	master   = mpi_comm.Get_size()-1 
	
	if log:
		print("\n\n")
		print(f"Hello. I am slave #{slave_id} out of {master} slaves "\
			f"with angles:\n\n {slave_angles}\n\n")
	
	n = sp_params['n']
	L = sp_params['L']
	calcE = sp_params['calcE']
	
	TN_params  = sp_params['TN_params']
	BP_params  = sp_params['BP_params']
	circ       = sp_params['circ']
	H_list     = sp_params['H_list']
	angles_loc = sp_params['angles_loc']
	
	glist = circ['glist']
	
	command = 'grad'
	
	while command == 'grad':
		
		(command, theta) = mpi_comm.recv(source=master, tag=0)
		
		if command=='grad':
			
			glist = update_angles(L, n, glist, angles_loc, theta)
			circ['glist'] = glist

			if log:
				print(f"Slave {slave_id}: calculating grad of {slave_angles}...")
			
			t0 = time.time()
			
			if calcE and slave_id==0:
				E, slave_grad, total_err = estimate_circ(TN_params, BP_params, \
					circ, H_list, slave_angles, just_grad=False)
			
				mpi_comm.send((slave_grad, E), dest=master, tag=1)
			else:
				E, slave_grad, total_err = estimate_circ(TN_params, BP_params, \
					circ, H_list, slave_angles, just_grad=True)
			
				mpi_comm.send(slave_grad, dest=master, tag=1)
				
			t1 = time.time()
			
			if log:
				print(f"\n\nslave {slave_id}  circ-time: {(t1-t0):.6g}secs\n\n")
			

			
	print("\n\n")
	print("--------------------------------------------------------------\n"\
		   f"Slave #{slave_id}: no more calculations are needed --- quitting!\n"\
		    "--------------------------------------------------------------\n\n")
	
		
		
		
#
# -------------------------   mpi_slave   ------------------------------ 
#
def quit_slaves(mpi_comm):
	
	slaves_no = mpi_comm.Get_size()

	print("\n\n\n")
	print("   >>>> Telling all slaves to quit <<<<<\n\n")
	for slave_id in range(slaves_no):
		mpi_comm.send( ('quit', None), dest=slave_id, tag=0)


		

#
# ---------------------- just_energy ------------------------------
#

def just_energy():


	seed = 14

	n = 6
	L = 10
	g = 0.6

	# 
	# Shot-noise parameter: 
	#   M = how many shots used to evaluate expectation value. 
	#       Use M=None to elimitate shot-noise.
	#
	
	M = None
	
	#
	# Depolarizing parameter  rho -> (1-lam)rho + lam*Id/2
	#

	lam = 1e-3

	#
	# BP parameters
	#

	BP_MAX_ITER = 200
	BP_DELTA    = 1e-6
	BP_DAMPING  = 0.0
	
	D_MAX       = 200


	#
	# ---------------------  PROGRAM STARTS HERE  -----------------------
	#

	np.random.seed(seed)

	pepsdm_initialize()
		
	e_list, e_dict = comb_graph(n)
	T_list = all_zeros(e_list)

	#
	# Initialize the TN dict
	#
	
	TN_params={}
	TN_params['T_list'] = T_list
	TN_params['e_list'] = e_list
	TN_params['e_dict'] = e_dict
	TN_params['D_max']  = D_MAX
	TN_params['M'] = M

	#
	# Initialize the BP dict
	#
	
	BP_params = {}
	BP_params['m_list'] = 'U'
	BP_params['BP_max_iter'] = BP_MAX_ITER
	BP_params['BP_delta'] = BP_DELTA
	BP_params['BP_damping'] = BP_DAMPING
	
		
	circ, angles_loc, H_list = HVA_TIM(n,g,L, lam)
	
	sp_params={}
	sp_params['n'] = n
	sp_params['L'] = L
	sp_params['TN_params']  = TN_params
	sp_params['BP_params']  = BP_params
	sp_params['circ']       = circ
	sp_params['H_list']     = H_list
	sp_params['angles_loc'] = angles_loc
	
	theta = [float(x) for x in sys.argv[2:]]
	
	if len(theta) !=2*L:
		print("\n")
		print(f"Error! Expecting {2*L} angles, but got {len(theta)}!\n")
		exit(1)
	
	x = array(theta)
	
	E = scipy_f(x, sp_params)
	

	sys.stdout.write(str(E))
	
	
	
	
	
	
	
	

########################################################################
#                                                                      #
#                       M A I N   P R O G R A M                        #
#                                                                      #
########################################################################


def main():

	#
	# ------------------   SET MAIN PARAMETERS  ------------------------
	#


	seed = 14

	n = 6
	L = 10
	g = 0.6

	# 
	# Shot-noise parameter: 
	#   M = how many shots used to evaluate expectation value. 
	#       Use M=None to elimitate shot-noise.
	#
	
	M = 1000  
	
	#
	# Depolarizing parameter  rho -> (1-lam)rho + lam*Id/2
	#

	lam = 1e-3



	optimizer = 'ADAM'

	
	
	#
	# ADAM parameters
	#
	
	T =   2500     # Total number of iterations
	LR0 = 0.02     # Initial learning rate
	LR1 = 0.001    # Final learning rate
	


	BP_MAX_ITER = 200
	BP_DELTA    = 1e-6
	BP_DAMPING  = 0.0
	
	D_MAX       = 200


	#
	# ---------------------  PROGRAM STARTS HERE  -----------------------
	#

	np.random.seed(seed)

	pepsdm_initialize()
		
	e_list, e_dict = comb_graph(n)
	T_list = all_zeros(e_list)

	#
	# Initialize the TN dict
	#
	
	TN_params={}
	TN_params['T_list'] = T_list
	TN_params['e_list'] = e_list
	TN_params['e_dict'] = e_dict
	TN_params['D_max']  = D_MAX
	TN_params['M'] = M

	#
	# Initialize the BP dict
	#
	
	BP_params = {}
	BP_params['m_list'] = 'U'
	BP_params['BP_max_iter'] = BP_MAX_ITER
	BP_params['BP_delta'] = BP_DELTA
	BP_params['BP_damping'] = BP_DAMPING
	
		
	circ, angles_loc, H_list = HVA_TIM(n,g,L, lam)
	
	sp_params={}
	sp_params['n'] = n
	sp_params['L'] = L
	sp_params['TN_params']  = TN_params
	sp_params['BP_params']  = BP_params
	sp_params['circ']       = circ
	sp_params['H_list']     = H_list
	sp_params['angles_loc'] = angles_loc
	
	if optimizer=='ADAM':
		sp_params['calcE']      = True
	else:
		sp_params['calcE']      = False

	#
	# ----------------------------------------------------------
	# See if we're running in MPI mode, and if we are, make sure 
	# that its with the right number of nodes (= slaves_no+1)
	# ----------------------------------------------------------
	#

	isMPI=False

	if MPI:

		mpi_comm = MPI.COMM_WORLD
		mpi_rank = mpi_comm.Get_rank()
		mpi_size = mpi_comm.Get_size()

		#
		# if mpi_size==1 then probably mpi4py is installed, but
		# the program is *not* called using mpirun --- so its a regular
		# run without MPI.
		#
		if mpi_size>=2:
			
			if mpi_size<3:
				if mpi_rank==mpi_size-1:
					print("\n\n")
					print(f"Error! Number of MPI processes cannot be 2. It must "\
					 "be either 1 or >= 3\n\n")
				
				exit(0)
				

			isMPI=True
			
			slaves_no = mpi_size-1
			
				
			slaves_partition = get_slaves_partition(n, L, slaves_no, angles_loc)
			
			#
			# The slaves are numbered 0,1,..., mpi_size-2
			#
			# The master is numbered mpi_rank := mpi_size-1 (last one)
			#
			
			if mpi_rank < mpi_size-1:
				mpi_slave(mpi_comm, sp_params, slaves_partition[mpi_rank])

				exit(0)


	if isMPI and mpi_rank==mpi_size-1:
		print("\n\n")
		print(f"  * * *   Running in MPI mode with {mpi_size-1} slaves"
			f" and one master   * * *\n\n")

	if not isMPI:
		mpi_comm = None
	
	sp_params['mpi_comm'] = mpi_comm
	
	
	if False:
		
		print("circ:")
		glist = circ['glist']
		for t, gate in enumerate(glist):
			gname, i, j, params = gate
			if j is None:
				locs = f'{i}'
			else:
				locs = f'{i}-{j}'
				
			print(f"g[{t}] = {gname}({locs})")
			
		
		print("\n")
		print("angles locations: ", angles_loc)
		print("total no. of angles: ", len(angles_loc))


	theta = 0.2*(np.random.uniform(size=2*L)-0.5*np.pi*ones(2*L)) + np.pi*ones(2*L)

		
	
	x0 = theta.copy()


	
	print("\n")
	print(f"==========   Optimizer: {optimizer}  n={n}  L={L}   seed={seed}  ========\n") 
	
	x0 = theta

	t0 = time.time()
	
	match optimizer:
		case 'COBYLA':
			res = minimize(scipy_f, x0, args=sp_params, method='COBYLA', \
				tol=1e-6, options={'maxiter':4000, 'disp':True})
				
		case 'COBYQA':
			res = minimize(scipy_f, x0, args=sp_params, method='COBYQA', \
				tol=1e-6, options={'maxiter':4000, 'disp':True})

		case 'Nelder-Mead':
			res = minimize(scipy_f, x0, args=sp_params, method='Nelder-Mead', \
				tol=1e-6, options={'maxiter':4000, 'disp':True})

		case 'Powell':
			res = minimize(scipy_f, x0, args=sp_params, method='Powell', \
				tol=1e-10, options={'maxiter':4000, 'disp':True})
				
		case 'BFGS':
			res = minimize(scipy_f, x0, jac=scipy_jac, args=sp_params, method='BFGS', \
				tol=1e-7, options={'maxiter':700, 'disp':True})

		case 'CG':
			res = minimize(scipy_f, x0, jac=scipy_jac, args=sp_params, method='CG', \
				tol=1e-7, options={'maxiter':400, 'disp':True})
	


	if optimizer != 'ADAM':
		t1 = time.time()
		
		#
		# If we're on  MPI mode then tell all slaves to quit
		#
		if isMPI:
			quit_slaves(mpi_comm)
			print("\n\n\n")
			time.sleep(10)
			print("\n\n\n")
			
		
		print("\n\nres= ", res)
		print("\n\n")
		print(f"E = {res.fun:.10g}\n")
		print("final x: ", res.x)
		print("\n")
		print(f"Total runnning time: {(t1-t0):.6g} secs\n")
		
		#
		# If we're on  MPI mode then tell all slaves to quit
		#
		if isMPI:
			quit_slaves(mpi_comm)
		
		
		return 

	#####################    A D A M    #####################
	
	
	fname = f'adam{seed}.txt'
	
	m,v = None, None
	
	oldE = None
	
	for k in range(T):
		
		t0 = time.time()
		
		LR = LR0*(LR1/LR0)**(k/T)

		print("\n\n\n\n")
		print("===========================================================")
		print(f"       Seed {seed}       R O U N D  {k}  LR = {LR:.6g}")
		print("===========================================================")
		print("\n\n\n")
		
		print(f"theta: {theta}")
		
		
		dtheta,E = scipy_jac(theta, sp_params)

		print("\n\n")
		print(f"Energy({k}): {E:.6g}\n")
		print(f"grad: {dtheta} \n\n")

			
		logfile = open(fname, 'a')
		logfile.write(f'{k}  {E:.6g}\n')
		logfile.close()
			
		#
		# Update theta
		#
		
		delta, m, v = ADAM_optimizier(m, v, dtheta, k+1)
		
		max_dtheta = max(abs(dtheta))
		print(f"dtheta: {dtheta[:5]} (max = {max_dtheta:.6g})")
		print(f"ADAM delta: {delta[:5]}")

		theta  = theta - LR*delta

		t1 = time.time()
		delta_t = t1-t0
		
		print()
		print(f"  (*) Computation time: {delta_t:.6g} secs\n")
		print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n\n")
		
		if oldE is not None:
			if abs(oldE-E)/abs(E) < 1e-5 and max_dtheta<1e-4:
				print("\n\n")
				print("    *  *  *    Energy is almost constant --- Quiting!    *  *  *\n\n")
				break
				
		oldE = E

		
	#
	# If we're on  MPI mode then tell all slaves to quit
	#
	if isMPI:
		quit_slaves(mpi_comm)

########################################################################

#
# If the command line contains 'eval' as the first input parameter, 
# then invoke the just_energy() function
#

P1 = sys.argv[1]
if P1=='eval':
	just_energy()
else:
	main()
