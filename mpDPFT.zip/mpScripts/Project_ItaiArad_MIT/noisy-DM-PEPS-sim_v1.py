#!/usr/bin/python3

########################################################################
#
#
#                   noisy-DM-PEPS.py
#                   =================
#
#
# History:
# ---------
#
# 31-Mar-2025  Itai  Initial version.
#
#
#
#
########################################################################


import sys

import numpy as np
import scipy as sp

import pickle
import time
import re

from numpy import tensordot, zeros, conj, ones, array, exp, sqrt, pi, \
	dot, vdot, eye, log, trace, diag

from numpy.linalg import norm, det, inv
from scipy.linalg import expm

from qbp import calc_e_dict, qbp, get_Bethe_free_energy
from BPSU import BP_gauging, apply_2local_gate, merge_SU_weights

from TenQI import *

#
# ------------------------  initialize  ----------------------------
#

def initialize():

	"""

	Set some global variables.

	Create a global list of 1-local Paulis and a list of 2-local Paulis.

	These lists are used in the gate_channel() function for finding the PTM
	representation of unitary channels.

	"""

	global Paulis2, Paulis1, Paulis1arr, Paulis2arr, simp_mat, \
		CNOT01, CNOT10, H, sZ_gate, sX_gate, T_gate

	#
	# 1D list and 2D list of the Pauli matrices. This is used for
	# bookkeeping k=1 and k=2 channels in the PTM.
	#

	Paulis1 = [ID1, sigma_X, sigma_Y, sigma_Z]

	Paulis2 = [[None]*4 for i in range(4)]
	

	for i in range(4):
		for j in range(4):
			T = tensordot(Paulis1[i], Paulis1[j], 0)
			Paulis2[i][j] = op_to_mat(T)

	#
	# We also create an array-version of Paulis lists
	#
	Paulis1arr = zeros([4,2,2], dtype=np.complex128)
	Paulis2arr = zeros([4,4,2,2,2,2], dtype=np.complex128)
	
	Paulis1arr[0,:,:] = ID1.copy()
	Paulis1arr[1,:,:] = sigma_X.copy()
	Paulis1arr[2,:,:] = sigma_Y.copy()
	Paulis1arr[3,:,:] = sigma_Z.copy()
	
	for al in range(4):
		for beta in range(4):
			Paulis2arr[al,beta,:,:,:,:] = tensordot(Paulis1[al],Paulis1[beta],0)
	


	#
	# The simplectic mat M[alpha, beta] encodes if the two Pauli
	# matrice P_alpha, P_beta commute (M[alpha,beta]=0) or anti-commute
	# (M=1)
	#

	simp_mat = np.zeros([4,4], dtype=np.int32)

	simp_mat[1,2] = simp_mat[2,1] = 1
	simp_mat[2,3] = simp_mat[3,2] = 1
	simp_mat[1,3] = simp_mat[3,1] = 1

	#
	# Some useful unitary gates
	#

	CNOT01 = tensordot(ketbra00, ID1, 0) +  tensordot(ketbra11, sigma_X, 0)
	CNOT10 = CNOT01.transpose([2,3,0,1])

	H = array([[1,1],[1,-1]])/sqrt(2)

	sZ_gate = diag([1,1j])
	sX_gate = 0.5*array([ [1+1j, 1-1j], [1-1j, 1+1j]])
	
	T_gate = diag([1, exp(1j*pi/4)])





#
# -----------------------  simp_inp  ---------------------
#

def simp_inp(alpha, beta):

	"""

	Calculates the symplectic inner-product between two Pauli strings
	alpha, beta. This is the number ip (either 0,1) such that:

	            P_alpha P_beta = (-1)^ip P_beta P_alpha

	"""

	k=len(alpha)

	s = 0
	for i in range(k):
		s += simp_mat[alpha[i], beta[i]]

	return s



#
# -----------------------  comp_to_PTM  ---------------------
#

def comp_to_PTM(F):

	r"""

	Given a Kraus operator F, produces the tensor that represnets
	the super-operator F\cdot F^\dagger in the PTM representation.


	Input Parameters:
	-------------------
	F --- The Kraus operator.
	      F can be either 1 local or 2 local. In the 2-local case, it is
	      given as a tensor in the form [i0,j0; i1,j1] where

	      F = \sum_{i0,j0; i1,j1} U[i0,j0; i1,j1] \cdot |i0><j0| \otimes |i1><j1|


	Output:
	-------

	The super-operator in PTM representation:

	(*)  for 1-local: T_{bet,al}
	(*)  for 2-local: T_{bet0,al0; bet1,al1}

	Explicitly, for the 2-local case, for

	rho = sum_{al0,al1} rho_{al0,al1} sigma_al0\otimes \sigma_al1

	We have:

	E(rho) = sum_{bet0,bet1} rho'_{bet0,bet1} sigma_bet0\otimes \sigma_bet1

	where:

	rho'_{bet0,bet1} := \sum_{al0,al1} T_{bet0,al0; bet1,al1} rho_{al0,al1}



	"""


	k = len(F.shape)//2

	if k==1:
		#
		# It's a 1-qubit gate. Resulting tensor is T_{alpha,beta}
		#
		
		P_alpha_F = tensordot(Paulis1arr, F, axes=([2],[0]))
		P_beta_Fdag =  tensordot(Paulis1arr, conj(F.T), axes=([2],[0]))
		
		# our tensors are of the form [alpha, i, j]
		
		T = (tensordot(P_alpha_F, P_beta_Fdag, axes=([1,2],[2,1]))).real

	if k==2:
		#
		# It's a 2-qubits operator.
		#
		# Tensor should be of the form [alpha0,beta0; alpha1,beta1]
		#

			
		#
		# Recall, Paulis2arr is of the form:
		# [al0,al1; i0,j0; i1,j1]
		#
		# U is of the form [i0,j0; i1,j1]
		#
		
		P_alpha_F = tensordot(Paulis2arr, F, axes=([3,5],[0,2]))
		P_beta_Fdag = tensordot(Paulis2arr, conj(F), axes=([3,5],[1,3]))
		
		#                                0   1      2  3  4 5
		# Now P_alpha_F is of the form [al0,al10; i0,i1,j0,j1]
		# P_beta_Fdag form:            [beta0,beta1; 
		
		T = (tensordot(P_alpha_F, P_beta_Fdag, axes=([2,3,4,5],[4,5,2,3]))).real
		#
		# T form: [al0,al1,beta0,beta1]
		#
		T = T.transpose([0,2,1,3])


	T = T/2**k
	return T

#
# -----------------------  channel_to_PTM  ---------------------
#

def channel_to_PTM(F_list):
	
	r"""
	
	Given a Kraus channel \sum_k F_k \rho F_k^\dagger, this function
	returns the representation of the channel in the PTM representation.
	
	Input Parameters:
	-----------------
	F_list --- A list of (either 1-local or 2-local) Kraus operators in 
	           the computational basis
	
	Output:
	-------
	The PTM of the channel
	
	"""
	
	M = None
	
	for F in F_list:
		#
		# Go over all the Kraus operators of the channel, and turn each 
		# one of them to a PTM matrix. Then we add all these matrices 
		# together to get the PTM matrix of the total channel
		#
		
		FM = comp_to_PTM(F)
		
		if M is None:
			M = FM
		else:
			M = M + FM
			
	return M




#
# -------------------------   comb_graph   -----------------------------
#

def comb_graph(n):
	
	r"""
	
	Creates a "comb" TN graph with n data qubits and n ancila qubits.
	
	For example, for n=5, we have the following graph:
	
	  5       6       7       8       9
	  |       |       |       |       |
	 leg-0   leg-1   leg-2   leg-3   leg-4
	  |       |       |       |       |
	  0-------1-------2-------3-------4
	    e0-1     e1-2    e2-3    e3-4
	    
	    
	For a data qubit k, the order of the legs are: 
	e{k-1}-k, e{k}-{k+1}, leg-k
	
	Input Parameters:
	-----------------
	n --- number of "legs" in the comb
	
	Output:
	-------
	
	e_list, e_dict --- The data structure of the TN graph
	
	"""
	
	e_list = []
	
	#
	# add the edges of the data qubits 0,1,..., n-1
	#
	for i in range(n):
		es = []
		
		if i>0:
			es.append(f'e{i-1}-{i}')
			
		if i<n-1:
			es.append(f'e{i}-{i+1}')
			
		es.append(f'leg-{i}')
		
		e_list.append(es)
		
	#
	# Add the edges of the ancilas
	#

	for i in range(n):
		es = [f'leg-{i}']
		e_list.append(es)

	e_dict = calc_e_dict(e_list)
		
	return e_list, e_dict
		

#
# -------------------------   get_gate   -------------------------------
#

def get_gate(gname, params=None):
	
	"""
	
	Given a gate name (a string) and an optional parameter (like 
	the rotation angle in a single-qubit rotation), return
	the corresponding local channel in the PTM form.
	
	To do that, we first create a Kraus representation of the channel, 
	as a list of Kraus operators, and then call the channel_to_PTM
	function to turn it into a matrix in the PTM representation.
	
	"""
	
	
	match gname:
		
		case 'Id':
			F_list = [ID1]
			
		case 'x':
			F_list = [sigma_X]
				
		case 'y':
			F_list = [sigma_Y]
			
		case 'z':
			F_list = [sigma_Z]
			
		case 'H':
			F_list = [H]
			
		case 'sx':
			F_list = [sX_gate]
			
		case 'sz':
			F_list = [sZ_gate]
			
		case 'T':
			F_list = [T_gate]
			
		case 'CNOT01':
			F_list = [CNOT01]
			
		case 'CNOT10':
			F_list = [CNOT10]
			
		case 'rx':
			theta = params['theta']
			F_list = [expm(-0.5j*theta*sigma_X)]
		
		case 'ry':
			theta = params['theta']
			F_list = [expm(-0.5j*theta*sigma_Y)]

		case 'rz':
			theta = params['theta']
			F_list = [expm(-0.5j*theta*sigma_Z)]
			
		case _:
			print(f"Error!  gate {gname} undefined")
			exit(1) 
			
	#
	# move from the computational basis to PTM
	#
	
	M = channel_to_PTM(F_list)
			
	return M



#
# ---------------------------   avPstr   ------------------------------
#

def avPstr(TN_params, BP_params, Pstr):
	"""
	
	Uses BP to calculates the (un-normalized) expectation value of a 
	Pauli string 
	
	<P> := Tr(\rho P)
	
	
	Input Parameters:
	------------------
	TN_params --- A dictionary holding the TN parameters
	
	BP_params --- A dictionary holding the BP params
	
	Pstr --- A list or integer array of length n that holds the Pauli
	         string. Each entry A[i] is a number is {0,1,2,3}, of the 
	         corresponding Pauli.
	         
	Output:
	-------
	The real number Tr(\rho P)
	
	"""

	#
	# Extract the TN params and the BP params
	#
	T_list = TN_params['T_list']
	e_list = TN_params['e_list']
	e_dict = TN_params['e_dict']


	BP_max_iter = BP_params['BP_max_iter']
	BP_delta    = BP_params['BP_delta']
	BP_damping  = BP_params['BP_damping']
	
	#
	# Contract the physical legs of the PEPS with the local Paulies
	#

	pT_list = []
	for i, T in enumerate(T_list):
		al = Pstr[i]
		pT = T[al,:]
		
		if norm(pT)<1e-13*norm(T):
			return 0.0
		
		pT_list.append(pT)

	
	#
	# Run BP 
	#
		
	m_list, err, iter_no = qbp(pT_list, e_list, e_dict, initial_m='U',\
		max_iter=BP_max_iter, delta=BP_delta, damping=BP_damping)
	
	for e in e_dict.keys():
		i,i_leg, j, j_leg = e_dict[e]
		
	F_Bethe = get_Bethe_free_energy(m_list, pT_list, e_list, e_dict)
	
	if F_Bethe.real>300:
		return 0.0
	else:
		trTN = exp(-F_Bethe)
		
		#
		# By definition, the expectation value of Pauli string is real
		#
		return trTN.real
	


#
# ---------------------------   avH   ------------------------------
#

def avH(TN_params, BP_params, H_list, nr=False):
	
	"""
	
	Calculate the energy of an MPS state with respect to a Hamiltonian.
	
	Input Parameters:
	------------------
	mp     --- The MPS
	
	H_list --- The Hamiltonian, given as a list of taples (c, Pstr), 
	           where Pstr is an integer array specifying a Pauli string
	           and c is the coefficient of this string in the expansion
	           of H
	           
  nr     --- Whether or not to normalize the result, 
             i.e. Tr(\rho H)/Tr(\rho)
	
	Output:
	-------
	The expectation value Tr(rho H)  (or Tr(rho H)/Tr(rho))
	
	"""
	
	av = 0.0
	
	for (c, Pstr) in H_list:
		
		av += c*avPstr(TN_params, BP_params, Pstr)
		
	if nr:
		#
		# Normalize
		#
		
		n = len(TN_params['T_list'])
		IDstr = zeros(n, dtype=np.int32)

		Tr_rho = avPstr(TN_params, BP_params, IDstr)
		
		av = av/Tr_rho
		
	return av
	
		
#
# ------------------------   apply_gate   ------------------------------
#		

def apply_gate(TN_params, BP_params, gate, t):
	"""
	
	Applies a 1- or 2-local gate to the TN. The gate is actually a 
	channel given in the Kraus representation in the computational basis.
	
	If the gate is 1-local, then we directly apply it to the phyical leg
	of the TN. 
	
	If the gate is 2-local, we first run BP, then move the Vidal gauge,
	apply the gate and truncate to the Dmax parameter of the TN.
	
	The gate is given as a taple: (gname, i, j, params), where:
	
     gname ---  The string that identifies the gate (defined in the
	              get_gate() function)       
	   i,j   ---  The  vertices on which it is defined. Note (i,j) must
	              be an edge in the TN graph
	   params --- optional parameters dictionary for the gate (used in 
	              the get_gate() function)
	              
	Input Parameters:
	-----------------
	TN_params --- A dictionary with the TN parameters
	
	BP_params --- A dictionary with the BP parameters
	
	gate      --- The taple of the gate (see above)
	
	t         --- An optional integer specifying the time step. This is
	              only used in the output message
	              
	              
	Output:
	-------
	T_list    --- The updated tensors
	m_list    --- The output BP messages (can be re-used later)
	trunc_err --- Truncation error (if gate is 2-local)
	
	"""

	log = False

	#
	# Extract the gate parameters
	#
	
	gname, i, j, params = gate
	
	#
	# Get the gate in the PTM form
	#
	M = get_gate(gname, params)
	
	if log:
		print("\n")
		if j is None:
			print(f"Step {t}: applying the 1-local gate {gname} on qubit {i}")
		else:
			print(f"Step {t}: applying the 2-local gate {gname} on qubits {i,j}")

	#
	# Extract the TN params and the BP params
	#
	T_list = TN_params['T_list']
	e_list = TN_params['e_list']
	e_dict = TN_params['e_dict']
	D_max  = TN_params['D_max']
	
	#
	# See if the gate is 1-local or 2-local. In the 1-local case, we 
	# simply apply it on the physical leg. In the 2-local case, we need
	# to run BP, move to the Vidal gauge, apply the gate and then compress.
	#
	
	if j is None:
		#
		# -------------- 1-local gate ------------------
		#
		
		T = T_list[i]
		T_list[i] = tensordot(M, T, axes=([1],[0]))
		
		T_list[i] = T_list[i]/norm(T_list[i])
		
		m_list = BP_params['m_list']
		
		trunc_err = 0
		
	else:
		#
		# -------------- 2-local gate ------------------
		#

		#
		# First, we find the edge that connects i,j
		#
		
		es_i, es_j = e_list[i], e_list[j]
		common_es = list(set(es_i).intersection(es_j))
		
		if len(common_es) != 1:
			print("\n")
			print(f"Error!!! vertices {i},{j} do not have a common unique edge")
			exit(1)
			
		e = common_es[0]

		#
		# Next, run BP and pass to the Vidal Gauge
		#

		m_list      = BP_params['m_list']
		BP_max_iter = BP_params['BP_max_iter']
		BP_delta    = BP_params['BP_delta']
		BP_damping  = BP_params['BP_damping']
		
		#
		# Run BP 
		#
		
		if log:
			print("\n")
			print("Running BP...")
		
		m_list, err, iter_no = qbp(T_list, e_list, e_dict, initial_m='U', \
			max_iter=BP_max_iter, delta=BP_delta, damping=BP_damping)
		
		if log:
			print("\n")
			print(f"BP finished after {iter_no} iterations with err={err:.6g}")
			
		gT_list, w_dict = BP_gauging(T_list, e_dict, m_list)
		
		#
		# The apply_2local_gate function assumes that e=(i,j) and that
		# i<j. So if i>j, we need to transpose the legs of M
		#
		
		if i>j:
			M = M.transpose([2,3,0,1])
		
		gT_list, w_dict, trunc_err = apply_2local_gate(gT_list, e_list,  \
			e_dict, w_dict, M, e, Dmax=D_max)
			
		gT_list[i] = gT_list[i]/norm(gT_list[i])
		gT_list[j] = gT_list[j]/norm(gT_list[j])
			
		T_list = merge_SU_weights(gT_list, e_dict, w_dict)
			
			
	
	
	return T_list, m_list, trunc_err

#
#----------------------   simulate_to_end    ---------------------------
#

def simulate_to_end(TN_params, BP_params, gates_list, H_list, t=0, \
	total_err=0):
		
	
	for gate in gates_list:
		
		T_list, m_list, trunc_err = apply_gate(TN_params, BP_params, gate, t)
		
		TN_params['T_list'] = T_list
		BP_params['m_list'] = m_list

		total_err += trunc_err
					
		t += 1

	E = avH(TN_params, BP_params, H_list, nr=True)
	
	return E, total_err
	
	
	

# ------------------------   estimate_circ  -------------------------
#

def estimate_circ(TN_params, BP_params, circ, H_list, angles_loc=[]):
	
	r"""

	Given a circuit, a Hamiltonian and a set of locations of 
	differentiable rotations in the circuit, return the energy of the 
	final state \rho with respect to the Hamiltonian, together with 
	gradient of the energy with respect to the rotations.
		
	Input Parameters:
	------------------
	TN_params --- A dictionary with the TN parameters
	
	BP_params --- A dictionary with the BP parameters
	
	circ       --- A dictionary holding the circuit info. This includes:
	
	               (*) circ['n']     --- Number of qubits
	               
	               (*) circ['glist'] --- A list of taples 
	                                     (gate_name, i, params)
	                                     describing the circuit
	                                
	H_list     --- The Hamiltonian as a list of Pauli strings and their
	               weights (c, Pstr)
	           
	
	angles_loc --- A list of positions of the rotations where we want
	               to calculate the gradient. This is done using the 
	               shift-rule.
	         
	
	Output:
	-------
	E         --- The final energy
	grad      --- An array holding the gradient corresponding to angle_loc 
	total_err --- Total truncation error (for the energy calc)
	
	"""
	
	log = False
	
	
	glist = circ['glist']
	
	#
	# Prepare the initial state |0>^n
	#
	e_list = TN_params['e_list']
	T_list = all_zeros(e_list)
	
	TN_params['T_list'] = T_list
	
	T_num = len(glist)
	
	total_err = 0.0
	
	#
	# See if we need to calculate the gradient array or not
	#
	l = len(angles_loc)
	if l>0:
		grad = zeros(l)
	else:
		grad = None
	
	
	m = 0           # Index holding the current gradient location
	total_err = 0.0 # Total truncation error
	
	for t in range(T_num):
		
		gate = glist[t]
		
		(gname, i, j, params) = gate
		if j is None:
			locs=f'{i}'
		else:
			locs=f'{i}-{j}'
	
		if log:
			print("===================================================")
			print(f"At step t={t}/{T_num-1} g[{t}]={gname}({locs})")
			print("===================================================\n")
	
		#
		# See if we reached a rotation in the gradient
		#
		if t in angles_loc:
			
			#
			# If we need to calculate a gradient, then we use the shift-rule
			# and calculate the circuit with theta +/- pi/2.
			#
			# In such case we need to run the circuit twice from where 
			# we are all way to the end. One branch with theta+pi/2 and 
			# the other branch with theta-pi/2
			#
			
			glist1 = glist[t:]  # The circuit starting from here
			params1 = {}
			
			if log:
				print(" **** gate is in grad!! ****\n")
		
			if log:
				print(" > Calculate (+) branch: ")
				print("   ---------------------\n")
			
			#
			# Change theta -> theta+pi/2 and use a fresh copy
			# of the TN
			#
			params1['theta'] = params['theta'] + pi/2
			glist1[0] = (gname, i, j, params1)
			
			T_list1 = T_list.copy()
			TN_params1 = TN_params.copy()
			TN_params1['T_list'] = T_list1
			
			av_plus, err = simulate_to_end(TN_params1, BP_params, \
				glist1, H_list, t, total_err)
				
			if log:
				print(" > Calculate (-) branch: ")
				print("   ---------------------\n")
			
			#
			# Change theta -> theta-pi/2 and use a fresh copy
			# of the TN
			#
			params1['theta'] = params['theta'] - pi/2
			glist1[0] = (gname, i, j, params1)
			
			T_list1 = T_list.copy()
			TN_params1 = TN_params.copy()
			TN_params1['T_list'] = T_list1

			av_minus, err = simulate_to_end(TN_params1, BP_params, \
				glist1, H_list, t, total_err)
			
			#
			# Calculate the gradient using the parameter-shift rule
			#
			grad[m] = 0.5*(av_plus - av_minus)
			m += 1
		
		#
		# Apply the gate of step t
		#

		T_list, m_list, trunc_err = apply_gate(TN_params, BP_params, gate, t)
		
		TN_params['T_list'] = T_list
		BP_params['m_list'] = m_list

		total_err += trunc_err
	
	E = avH(TN_params, BP_params, H_list, nr=True)
		
	return E, grad, total_err

	
	
	
	
#
# --------------------------   all_zeros   -----------------------------
#
def all_zeros(e_list):
	r"""
	
	Create an initial TN in the Pauli representation that encodes the 
	state |0>^n
	
	"""
	
	n = len(e_list)
	
	T0 = array([0.5,0,0,0.5])  # Representation of |0><0| in Pauli basis
	
	T_list = []
	
	for es in e_list:
		l = len(es)
		sh = [4] + [1]*l  # the shape of the TN is [4,1,1,...]
		
		T = T0.reshape(sh)
		
		T_list.append(T)
		
	return T_list
			
#
# -----------------------    simple_circ    ----------------------------
#
def simple_circ():
	
	circ = {}
	
	glist = []
	
	glist.append( ('rx', 0, None, {'theta':0.2}) )
	glist.append( ('rx', 1, None, {'theta':0.9}) )
	glist.append( ('rx', 2, None, {'theta':-1.7}) )
	glist.append( ('rx', 3, None, {'theta':2.2}) )
	glist.append( ('rx', 4, None, {'theta':-0.7}) )

	glist.append( ('H',  0, None, None) )
	glist.append( ('rz', 1, None, {'theta':1.2}) )
	glist.append( ('ry', 2, None, {'theta':-0.6}) )
	glist.append( ('rz', 3, None, {'theta':0.9}) )
	glist.append( ('H',  4, None, None) )

	glist.append( ('CNOT01', 0, 1, None) )
	glist.append( ('CNOT01', 2, 3, None) )

	glist.append( ('ry', 1, None, {'theta':0.2}) )
	glist.append( ('rz', 2, None, {'theta':1.2}) )
	glist.append( ('CNOT10', 3, 4, None) )

	glist.append( ('ry', 0, None, {'theta':-0.6}) )
	glist.append( ('CNOT01', 1, 2, None) )
	glist.append( ('ry', 4, None, {'theta':-0.6}) )
	
	circ['glist'] = glist
	
	return circ

#
# -----------------------   HVA_TIM   ----------------------------------
#
def HVA_TIM(n,g, L):
	
	r"""
	"""
	
	circ = {}
	
	glist = []
	
	angles_loc = []
	
	t=0
	for l in range(L):
		
		#
		# Rx layer
		#
		
		theta = 2*pi*np.random.uniform()
		
		for i in range(n):
			glist.append( ('rx', i, None, {'theta':theta}) )
			angles_loc.append(t)
			t += 1
			
		#
		# Odd Rzz layer
		#
		theta = 2*pi*np.random.uniform()
			
		for i in range(0,n-1,2):
			glist.append( ('CNOT01', i, i+1, None) )
			t += 1

		for i in range(0,n-1,2):
			glist.append( ('rz', i+1, None, {'theta':theta}) )
			angles_loc.append(t)
			t += 1
		
		for i in range(0,n-1,2):
			glist.append( ('CNOT01', i, i+1, None) )
			t += 1
	
		#
		# Even Rzz layer
		#
			
		for i in range(1,n-1,2):
			glist.append( ('CNOT01', i, i+1, None) )
			t += 1

		for i in range(2,n-1,2):
			glist.append( ('rz', i, None, {'theta':theta}) )
			angles_loc.append(t)
			t += 1
		
		for i in range(1,n-1,2):
			glist.append( ('CNOT01', i, i+1, None) )
			t += 1
	
	circ['glist'] = glist
	
	#
	# Now define the TIM Hamiltonian with transverse field g
	#
	H_list = []
	
	for i in range(n-1):
		Pstr = zeros(2*n, dtype=np.int32)
		Pstr[i]=3
		Pstr[i+1]=3
		H_list.append( (-1, Pstr) )
	
	for i in range(n):
		Pstr = zeros(2*n, dtype=np.int32)
		Pstr[i]=1
		H_list.append( (-g, Pstr) )
	
	return circ, angles_loc, H_list

#
# ------------------------   ADAM_optimizer   -------------------------
#

def ADAM_optimizier(m, v, g, t):
	
#	return g, 1, 1
	
	EPSILON = 1e-8  # Prevent division by zero errors

	gamma_1 = 0.9     # Decay for first moment average
	gamma_2 = 0.999   # Decay for second moment average
	
	if m is None:
		m = zeros(g.shape[0])
		v = zeros(g.shape[0])
	
	new_m = gamma_1*m + (1-gamma_1)*g
	new_v = gamma_2*v + (1-gamma_2)*g**2
	
	m_hat = new_m/(1-gamma_1**t)
	v_hat = new_v/(1-gamma_2**t)
	
	delta = m_hat/(sqrt(v_hat)+EPSILON)
		
	return delta, new_m, new_v
	
	



#
# ------------------------    test    ----------------------------------
#
def test():

	#
	# ------------------   SET MAIN PARAMETERS  ------------------------
	#

	n = 5

	BP_MAX_ITER = 200
	BP_DELTA    = 1e-6
	BP_DAMPING  = 0.0
	
	D_MAX       = 200


	#
	# ---------------------  PROGRAM STARTS HERE  -----------------------
	#

	print("hello")
	np.random.seed(1)

	initialize()
		
	e_list, e_dict = comb_graph(n)
	T_list = all_zeros(e_list)

	#
	# Initialize the TN dict
	#
	
	TN_params={}
	TN_params['T_list'] = T_list
	TN_params['e_list'] = e_list
	TN_params['e_dict'] = e_dict
	TN_params['D_max']  = D_MAX

	#
	# Initialize the BP dict
	#
	BP_params = {}
	BP_params['m_list'] = 'U'
	BP_params['BP_max_iter'] = BP_MAX_ITER
	BP_params['BP_delta'] = BP_DELTA
	BP_params['BP_damping'] = BP_DAMPING
	
	
	circ = simple_circ()
	
	
	g=0.6
	
	H_list = []
	
	for i in range(n-1):
		Pstr = zeros(2*n, dtype=np.int32)
		Pstr[i]=3
		Pstr[i+1]=3
		H_list.append( (-1, Pstr) )
	
	for i in range(n):
		Pstr = zeros(2*n, dtype=np.int32)
		Pstr[i]=1
		H_list.append( (-g, Pstr) )
		
#	angles_loc = [0,1,2,3,4,6,13,17]
	angles_loc = []
	
	E, grad, total_err = estimate_circ(TN_params, BP_params, circ, \
		H_list, angles_loc)
			
		
	print("\n\n")
	print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n")
	print(f"Energy: {E:.6g}  (err={total_err:.6g})")
	print(f"grad: {grad} \n\n")
	
	T_save = TN_params['T_list'].copy()
	E2 = avH(TN_params, BP_params, H_list, nr=True)
	
	print("E2=", E2)
	
	E, grad, total_err = estimate_circ(TN_params, BP_params, circ, \
		H_list, angles_loc)
		
	print("\n\n")
	print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n")
	print(f"Energy: {E:.6g}  (err={total_err:.6g})")
	print(f"grad: {grad} \n\n")
	
	TN_params['T_list']=T_save
	E2 = avH(TN_params, BP_params, H_list, nr=True)
	
	print("E2=", E2)

	exit(0)
	

########################################################################
#                                                                      #
#                       M A I N   P R O G R A M                        #
#                                                                      #
########################################################################


def main():

	#
	# ------------------   SET MAIN PARAMETERS  ------------------------
	#

	n = 4

	BP_MAX_ITER = 200
	BP_DELTA    = 1e-6
	BP_DAMPING  = 0.0
	
	D_MAX       = 200

	L = 4
	g = 0.6
	LR = 0.005  # Learning rate
	
	T = 1000    # No. of iterations



	#
	#
	#

	#
	# ---------------------  PROGRAM STARTS HERE  -----------------------
	#

	print("hello")
	np.random.seed(1)

	initialize()
		
	e_list, e_dict = comb_graph(n)
	T_list = all_zeros(e_list)

	#
	# Initialize the TN dict
	#a
	
	TN_params={}
	TN_params['T_list'] = T_list
	TN_params['e_list'] = e_list
	TN_params['e_dict'] = e_dict
	TN_params['D_max']  = D_MAX

	#


	# Initialize the BP dict
	#
	BP_params = {}
	BP_params['m_list'] = 'U'
	BP_params['BP_max_iter'] = BP_MAX_ITER
	BP_params['BP_delta'] = BP_DELTA
	BP_params['BP_damping'] = BP_DAMPING
	
	
	circ, angles_loc, H_list = HVA_TIM(n,g,L)
	
	print("circ:")
	glist = circ['glist']
	for t, gate in enumerate(glist):
		gname, i, j, params = gate
		if j is None:
			locs = f'{i}'
		else:
			locs = f'{i}-{j}'
			
		print(f"g[{t}] = {gname}({locs})")
		
	
	print("\n")
	print("angles locations: ", angles_loc)
	print("total no. of angles: ", len(angles_loc))



  
#	theta_x  = array([3.42742267, 3.0081162,  3.28872095, 3.17954291, 3.11675945, 3.30782016])
#	theta_zz = array([3.33751259, 3.43834727, 3.30711984, 3.30443726, 3.29788843, 3.34685836])

	theta = np.pi*ones(2*L) + 1e-2*np.random.uniform(size=2*L)

	glist = circ['glist']
	for k in range(T):

		print("\n\n\n\n")
		print("===========================================================")
		print(f"                 R O U N D  {k}  ")
		print("===========================================================")
		print("\n\n\n")
		
		print(f"theta: {theta[:5]}...")
		
		
		#
		# Update the theta angles in the circuit:
		#
		# theta[2*l]   := Rx angle at the l layer
		# theta[2*l+1] := Rzz angle at the l layer
		#
		
		m,v = None, None
		
		for l in range(L):
			
			l0 = l*(2*n-1)
			#
			# Update the Rx of layer l
			#
			for i in range(l0, l0+n):
				t = angles_loc[i]
				gname, i0,j0, params = glist[t]
				params['theta'] = theta[2*l]

			#
			# Update the Rz of layer l
			#
			for i in range(l0+n, l0+2*n-1):
				t = angles_loc[i]
				gname, i0,j0, params = glist[t]
				params['theta'] = theta[2*l+1]
				

		#
		# Calculate energy + local gradients
		#


		E, grad, total_err = estimate_circ(TN_params, BP_params, circ, \
			H_list, angles_loc)
			
		
		print("\n\n")
		print(f"Energy({k}): {E:.6g}  (err={total_err:.6g})\n")
		print(f"grad: {grad} \n\n")
		
		
		logfile = open('adam.txt', 'a')
		logfile.write(f'{k}  {E:.6g}\n')
		logfile.close()
		
		
		
		#
		# Use the local gradients to calculate the 2L global gradients.
		#
		# To do that, we go over the layers. Each layer has 2n-1 angles:
		#
		# For even n:
		# ------------
		#  (*)  n     angles of Rx
		#  (*)  n/2   angles of even Rz
		#  (*)  n/2-1 angles of odd  Rz
		#
		# For odd n:
		# ------------
		#  (*)  n       angles of Rx
		#  (*)  (n-1)/2 angles of even Rz
		#  (*)  (n-1)/2 angles of odd  Rz
		
		dtheta = zeros(2*L)
		
		for l in range(L):
			
			l0 = l*(2*n-1)
			
			#
			# calc the gradient of the Rx layer
			#
			for i in range(l0, l0+n):
				dtheta[2*l] += grad[i]
			
			
			#
			# calc the gradient of the Rzz layers
			#
			for i in range(l0+n, l0+2*n-1):
				dtheta[2*l+1] += grad[i]
					
		#
		# Now that we have the 2L global gradients, use the ADAM optimizer
		# to find the update rule of each one of the corresponding angles.
		#
		
		delta, m, v = ADAM_optimizier(m, v, dtheta, k+1)
		
		print(f"dtheta: {dtheta[:5]}")
		print(f"ADAM delta: {delta[:5]}")

		theta  = theta - LR*delta
		
		print()
		print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n\n")

			
		
	
	
		

#
# ---------------------- just_energy ------------------------------
#

def just_energy():
	

	#
	# ------------------   SET MAIN PARAMETERS  ------------------------
	#

	n = 6

	BP_MAX_ITER = 200
	BP_DELTA    = 1e-6
	BP_DAMPING  = 0.0
	
	D_MAX       = 200

	L = 6
	g = 0.6

	#
	# ---------------------  PROGRAM STARTS HERE  -----------------------
	#

	initialize()
		
	e_list, e_dict = comb_graph(n)
	T_list = all_zeros(e_list)

	#
	# Initialize the TN dict
	#
	
	TN_params={}
	TN_params['T_list'] = T_list
	TN_params['e_list'] = e_list
	TN_params['e_dict'] = e_dict
	TN_params['D_max']  = D_MAX

	#
	# Initialize the BP dict
	#
	BP_params = {}
	BP_params['m_list'] = 'U'
	BP_params['BP_max_iter'] = BP_MAX_ITER
	BP_params['BP_delta'] = BP_DELTA
	BP_params['BP_damping'] = BP_DAMPING
	
	
	circ, angles_loc, H_list = HVA_TIM(n,g,L)
	
	glist = circ['glist']
	
	angles = [float(x) for x in sys.argv[1:]]
	theta = array(angles)
	
	#
	# Update the theta angles in the circuit:
	#
	# theta[2*l]   := Rx angle at the l layer
	# theta[2*l+1] := Rzz angle at the l layer
	#
	
	for l in range(L):
		
		l0 = l*(2*n-1)
		#
		# Update the Rx of layer l
		#
		for i in range(l0, l0+n):
			t = angles_loc[i]
			gname, i0,j0, params = glist[t]
			params['theta'] = theta[2*l]

		#
		# Update the Rz of layer l
		#
		for i in range(l0+n, l0+2*n-1):
			t = angles_loc[i]
			gname, i0,j0, params = glist[t]
			params['theta'] = theta[2*l+1]
			

	#
	# Calculate energy + local gradients
	#


	E, grad, total_err = estimate_circ(TN_params, BP_params, circ, \
		H_list, [])
	
	sys.stdout.write(str(E))



		
#main()
#test()

just_energy()
